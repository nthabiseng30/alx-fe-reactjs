export default function Footer(){
  return (
    <footer style={{
      backgroundColor: 'yellow', // changed to yellow
      color: 'brown', // changed to brown
      textAlign: 'center',
      padding: '10px' // added padding
    }}>
      <p>&copy; 2023 City Lovers</p> // updated copyright text
    </footer>
  );
};
