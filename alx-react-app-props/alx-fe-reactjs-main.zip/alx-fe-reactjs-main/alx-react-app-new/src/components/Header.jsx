export default function Header(){
    return (
        <header style={{ backgroundColor: 'navy', color: 'white', textAlign: 'center' }}>
            <h1>My Favorite Cities</h1>
        </header>
    );
};