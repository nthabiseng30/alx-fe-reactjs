export default function MainContent(){
  return (
    <main style={{
      backgroundColor: 'green',
      color: 'black',
      textAlign: 'center',
      padding: '20px',
      fontSize: '18px'
    }}>
      <p>I love to visit New York, Paris, and Tokyo.</p>
    </main>
  );
};
