export default function Footer(){
    return (
        <footer>
            <p>© 2023 City Lovers</p>
        </footer>
    );
};